"""
Templates for deployment specifications
"""
