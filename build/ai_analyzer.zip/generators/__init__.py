"""
Generators for deployment specifications
"""
