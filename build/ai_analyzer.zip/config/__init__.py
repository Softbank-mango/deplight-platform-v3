"""
Configuration module for Lambda AI Analyzer
"""
